/*
 * Copyright (c) 2014 Qualcomm Technologies Inc
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted
 * (subject to the limitations in the disclaimer below) provided that the following conditions are
 * met:
 *
 * Redistributions of source code must retain the above copyright notice, this list of conditions
 * and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions
 * and the following disclaimer in the documentation and/or other materials provided with the
 * distribution.
 *
 * Neither the name of Qualcomm Technologies Inc nor the names of its contributors may be used to
 * endorse or promote products derived from this software without specific prior written permission.
 *
 * NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE. THIS
 * SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA,
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.qualcomm.robotcore.hardware;

import com.qualcomm.robotcore.util.SerialNumber;

/**
 * Interface for working with PWM Input Controllers
 * <p>
 * Different analog input controllers will implement this interface.
 */
public interface PWMOutputController extends HardwareDevice {

  /**
   * Serial Number
   *
   * @return return the USB serial number of this device
   */
  SerialNumber getSerialNumber();

  /**
   * Set the pulse width output time for this channel. Typically set to a value between
   * 750 and 2,250 to control a servo.
   * @param port port this device is attached to
   * @param usDuration pulse width for the port in microseconds.
   */
  void setPulseWidthOutputTime(int port, int usDuration);

  /**
   * Set the pulse width output period. Typically set to 20,000 to control servo.
   * @param port port this device is attached to
   * @param usPeriod pulse repetition period in microseconds.
   */
  void setPulseWidthPeriod(int port, int usPeriod);

  /**
   * Gets the pulse width for the channel output in units of 1 microsecond.
   * @param port port this device is attached to
   * @return time pulse width for the channel in microseconds.
   */
  int getPulseWidthOutputTime(int port);

  /**
   * Gets the pulse repetition period for the channel output in units of 1 microsecond.
   * @param port port this device is attached to
   * @return period pulse repetition period in microseconds.
   */
  int getPulseWidthPeriod(int port);
}
